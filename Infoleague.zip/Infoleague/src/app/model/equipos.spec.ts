import { Equipo } from './equipos';

describe('Equipo', () => {
  it('should create an instance', () => {
    expect(new Equipo()).toBeTruthy();
  });
});
