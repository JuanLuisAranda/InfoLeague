export class Equipo {
    id: number;
    name: string;
    escudo: string;
}
