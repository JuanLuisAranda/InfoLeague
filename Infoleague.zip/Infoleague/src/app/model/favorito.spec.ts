import { Favorito } from './favorito';

describe('Favorito', () => {
  it('should create an instance', () => {
    expect(new Favorito()).toBeTruthy();
  });
});
