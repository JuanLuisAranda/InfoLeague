export class Favorito {
    id?: number;
    name: string;
}
