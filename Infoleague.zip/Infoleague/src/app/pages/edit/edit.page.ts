import { Component, OnInit } from '@angular/core';
import { Favorito } from 'src/app/model/favorito';
import { FavoritoService } from 'src/app/services/favorito.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.page.html',
  styleUrls: ['./edit.page.scss'],
})
export class EditPage implements OnInit {

  id: String = "";
  favorito: Favorito = {
    name: ''
  };

  constructor(
    private favoritosService: FavoritoService,
    private router: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {

    const id = this.activatedRoute.snapshot.paramMap.get('id');
    if (id != null) {
      this.id = "Editar";
      this.favorito = this.favoritosService.getFavorito(+id);
    } else {
      this.id = "Añadir"
    }

  }

  saveFav() {
    this.favoritosService.saveFav(this.favorito).then(
      () => this.router.navigateByUrl(`/favorito`)
    );
    }

}
